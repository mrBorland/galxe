import time
import json
import random
import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import NoSuchElementException
import telebot

OTP_TOKEN = "7739907978:AAEfzWxMHySj-YtwJMx2V4hIloW4zAzAYcE"
CHAT_ID = "6821675571"
bot = telebot.TeleBot(OTP_TOKEN)

def send_telegram(msg):
    try:
        bot.send_message(CHAT_ID, msg)
    except:
        pass

def create_driver():
    options = uc.ChromeOptions()
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument("--user-agent=Mozilla/5.0 (Linux; Android 11)")
    return uc.Chrome(options=options)

def try_register_without_phone(driver, email, password):
    driver.get("https://accounts.google.com/signup")
    time.sleep(2)
    driver.find_element(By.ID, "firstName").send_keys("Bot")
    driver.find_element(By.ID, "lastName").send_keys("User")
    driver.find_element(By.ID, "username").send_keys(email)
    driver.find_element(By.NAME, "Passwd").send_keys(password)
    driver.find_element(By.NAME, "ConfirmPasswd").send_keys(password)
    driver.find_element(By.ID, "accountDetailsNext").click()
    time.sleep(5)
    try:
        driver.find_element(By.ID, "phoneNumberId")
        return False
    except NoSuchElementException:
        return True

def get_number_from_otpbot():
    send_telegram("/getnumber")
    send_telegram("[OTPBot] Очікую код...")
    for _ in range(60):
        updates = bot.get_updates()
        for u in updates[::-1]:
            if u.message and "+" in u.message.text:
                return u.message.text.strip()
        time.sleep(2)
    return None

def enter_phone_and_wait_code(driver, phone):
    driver.find_element(By.ID, "phoneNumberId").send_keys(phone)
    driver.find_element(By.ID, "gradsIdvPhoneNext").click()
    send_telegram("[OTPBot] Надішли код у відповідь")
    for _ in range(60):
        updates = bot.get_updates()
        for u in updates[::-1]:
            if u.message and u.message.text.strip().isdigit():
                code = u.message.text.strip()
                for c in code:
                    driver.find_element(By.ID, "code").send_keys(c)
                    time.sleep(0.5)
                return True
        time.sleep(2)
    return False

def save_account(email, password):
    try:
        with open("accounts_youtube.json", "r") as f:
            data = json.load(f)
    except:
        data = []
    data.append({"email": email, "password": password})
    with open("accounts_youtube.json", "w") as f:
        json.dump(data, f, indent=2)

def main():
    for i in range(100):
        email = f"smartbot{i}{random.randint(1000,9999)}@gmail.com"
        password = "SmartPass123!"
        driver = create_driver()
        try:
            send_telegram(f"[{i+1}] Пробую без номера: {email}")
            if try_register_without_phone(driver, email, password):
                send_telegram(f"[{i+1}] Успішно без номера: {email}")
                save_account(email, password)
                driver.quit()
                continue
            phone = get_number_from_otpbot()
            if phone and enter_phone_and_wait_code(driver, phone):
                send_telegram(f"[{i+1}] Успішно з OTP: {email}")
                save_account(email, password)
            else:
                send_telegram(f"[{i+1}] Провал з OTP: {email}")
        except Exception as e:
            send_telegram(f"[{i+1}] Помилка: {str(e)}")
        finally:
            driver.quit()

if __name__ == '__main__':
    main()
